import os
from Front_end import gui

if __name__ == "__main__":
    instance = gui.GUI()
    instance.start_gui()