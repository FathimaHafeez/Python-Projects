# Translator

This simple python script translates from one language to another using [googletrans](https://py-googletrans.readthedocs.io/en/latest/) python library.

To use this to your convenience, feel free to change the `kn` in the python file to any language listed in the above link.