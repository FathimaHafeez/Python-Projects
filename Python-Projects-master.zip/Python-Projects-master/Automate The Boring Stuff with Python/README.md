# Automate the Boring Stuff with Python Programming

This repository is home to the course resources of the very popular book and course [Automate the Boring Stuff with Python Programming](https://automatetheboringstuff.com/) by Al Sweigart.

The repository contains the course notes in the `Resources` folder and all the programs can be found in the `Programs` folder.
