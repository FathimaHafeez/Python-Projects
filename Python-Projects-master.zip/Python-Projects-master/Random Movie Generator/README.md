# Random Movie Generator


Bored? Don't know what to watch?

Just run this python script using `python script.py`. This script selects and displays a random movie from the IMDB's top 250 movies.