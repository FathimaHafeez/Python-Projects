# PONG

A simple Pong game created from the [Turtle](https://docs.python.org/3/library/turtle.html) module in python. The game consists of two players trying to bounce off a ball approaching towards their paddle. Upon missing the ball the opponent scores a point.
